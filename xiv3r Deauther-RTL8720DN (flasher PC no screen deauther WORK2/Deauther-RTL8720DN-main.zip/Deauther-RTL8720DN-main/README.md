# Deauther Firmware for RTL8720DN BW16

<img src="https://github.com/xiv3r/RT8720DN-Deauther/blob/main/rtl7820dn.png">

# Windows installation
- First [Download](https://github.com/xiv3r/Deauther-RTL8720DN/raw/refs/heads/main/CH341SER.EXE) and Install the CH340G driver for RTL8720DN

- [Download](https://github.com/xiv3r/Deauther-RTL8720DN/releases/download/RTL8720DN/RTL8720DN-Deauther.zip) and unzip the Firmware and Flasher

- Open the flasher and import the firmware and then flash

- Connect to the WiFi=`Ereshkigal` Password=`masukangin`

- Open the browser [http://192.168.1.1](http://192.168.1.1)

- Then you can start the attack


Credit: [Ereshkigal](https://github.com/Arifmaulanaazis/Ereshkigal)
