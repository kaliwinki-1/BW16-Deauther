# Deauther RTL8720DN
2G/5Ghz Deauther firmware for RTL8720DN BW16 MCU


<img src="https://github.com/xiv3r/RT8720DN-Deauther/blob/main/rtl7820dn.png">

# Installation (windows)
- First Install the driver for RTL8720D

- Download the [Firmware](https://raw.githubusercontent.com/xiv3r/Deauther-RTL8720DN/refs/heads/main/RTL8720DN_BW16_Deauther_v1.0.3.bin) and the [Flasher](https://raw.githubusercontent.com/xiv3r/Deauther-RTL8720DN/refs/heads/main/RTL8720DN_Flasher_v1.0.0.exe)

- Open the flasher and import the firmware then flash

- Connect to WiFi=`Ereshkigal` Password=`masukangin`

- Open the browser [http://192.168.1.1](http://192.168.1.1)

- Then you can start the attack



Credit: [Ereshkigal](https://github.com/Arifmaulanaazis/Ereshkigal)
