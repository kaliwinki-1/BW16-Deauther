# BW16-2.4GHz-5GHz-Deauther
A 2.4GHz and 5GHZ Deauther, based on a RTL8720dn BW16 dev kit.


The files will be updated soon! Make sure to get your BW16 ready!


Updates on Emensta's Community Discord server that you can join via https://emensta.pages.dev


In development together with:
[@ASP-29](https://github.com/ASP-29) - creator of the algorithm.


I focus on adding physical use (screen&buttons to navigate), aswell as the webservers design
