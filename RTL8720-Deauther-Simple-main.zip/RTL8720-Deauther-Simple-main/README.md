# RTL8720-Deauther-Simple
I gave a little touch of javascript and selected the target by simply checking it,based on tesa-klebeband's packet injection project https://github.com/tesa-klebeband/RTL8720dn-WiFi-Packet-Injection
# update 09-19-2024
added css to the html for better user interface
