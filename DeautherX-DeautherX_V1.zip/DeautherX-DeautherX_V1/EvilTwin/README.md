# DeautherX

## DeautherX Custom Captive Portals

DeautherX can create custom captive portals. Captive portals are commonly used in Wi-Fi networks to gain access to the password of any Wi-Fi access point by creating a twin of the access point and deauthenticating the real one. If the target connects to the fake access point, it will prompt the user to enter the password through a login or firmware update page. With DeautherX, you can customize these portals to suit your needs.

### HTML Files for Custom Captive Portal Attacks

DeautherX provides HTML files specifically designed for custom captive portal attacks. These files can be easily modified to create convincing and effective landing pages for phishing attacks, network testing, or educational demonstrations.

---
