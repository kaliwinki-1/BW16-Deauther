# RESET

Open the Reset_Sketch.ino and upload with the correct settings.  
