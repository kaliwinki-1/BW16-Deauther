___
# DeautherX

## DeautherX Web Interface

The HTML files for the DeautherX web interface are pre-compressed for convenience and ease of use. If you encounter any issues, feel free to contact us via Telegram at [@BlackTechX](https://t.me/BlackTechX).
___
