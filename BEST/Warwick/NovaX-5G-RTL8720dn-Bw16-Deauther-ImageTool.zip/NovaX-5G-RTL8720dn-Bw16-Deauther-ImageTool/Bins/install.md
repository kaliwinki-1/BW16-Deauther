
# Bin file installation tool for bw16

Download tool: [This](Image_Tool)
Press and hold `Burn` button, press then release `RST` button and release `Burn` button. to enter flash mode


## Step 1:
![Alt text](https://github.com/warwick320/5G-deauther-with-OLED-SSD1306/blob/1b62a11221ecf7fc34b595e254c4459736912f23/img/step1.png?raw=true)
## Step 2:
![Alt text](https://github.com/warwick320/5G-deauther-with-OLED-SSD1306/blob/1b62a11221ecf7fc34b595e254c4459736912f23/img/step2.png?raw=true)
## Step 3:
![Alt text](https://github.com/warwick320/5G-deauther-with-OLED-SSD1306/blob/1b62a11221ecf7fc34b595e254c4459736912f23/img/step3.png?raw=true)
## Step 4: 
![Alt text](https://github.com/warwick320/5G-deauther-with-OLED-SSD1306/blob/1b62a11221ecf7fc34b595e254c4459736912f23/img/step4.png?raw=true)
