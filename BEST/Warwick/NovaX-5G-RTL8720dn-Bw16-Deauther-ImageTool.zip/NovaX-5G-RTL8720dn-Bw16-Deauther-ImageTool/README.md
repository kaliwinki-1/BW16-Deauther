# Source
[Link](https://github.com/tesa-klebeband/RTL8720dn-Deauther)
# Requirement
1. RTL8720DN BW16
2. BUTTONS (3)
3. SSD1306 OLED
# Install bin
[This Link](Bins/install.md)
# Setup
 - Board Manger version 3.1.5 ( I use this version)  
 - Adafruit_SSD1306  
 - Adafruit GFX  
 - Tool -> Standard Lib Enable -> "Arduino_STD_PRINTF"  
# Connection
## button
1. Up PA27
2. Down PA12
3. OK PA13
## display
1. SCL PA25
2. SDA PA26
### If you have any problems, please chat on Discord. I only check Discord.
sihoo.320
